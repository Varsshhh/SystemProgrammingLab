void cmnprn(unsigned int n);   
