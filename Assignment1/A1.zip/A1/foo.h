void fooprn(unsigned int n); 
