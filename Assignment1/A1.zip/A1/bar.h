void barprn(unsigned int n); 
